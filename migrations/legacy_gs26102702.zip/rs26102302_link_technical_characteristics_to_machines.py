"""Связь технических характеристик с агрегатами и результат сопоставления."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_GENERATION, SCHEMA_RATIONAL_STRUCTURE

revision = "rs26102302"
down_revision = "rs26102301"
branch_labels = None
depends_on = None

TABLE = "gs_rs_turbine_technical_characteristics"


def upgrade():
    op.add_column(TABLE, sa.Column("machine_id", sa.Integer(), nullable=True), schema=SCHEMA_RATIONAL_STRUCTURE)
    op.add_column(
        TABLE,
        sa.Column("match_status", sa.String(20), nullable=False, server_default="not_checked"),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.add_column(
        TABLE,
        sa.Column("match_details", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.create_foreign_key(
        "fk_rs_turbine_machine", TABLE, "gs_gen_machines", ["machine_id"], ["id"],
        source_schema=SCHEMA_RATIONAL_STRUCTURE, referent_schema=SCHEMA_GENERATION,
        ondelete="SET NULL",
    )
    op.create_index(
        "ix_rs_turbine_version_machine", TABLE, ["database_version_id", "machine_id"],
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.create_check_constraint(
        "ck_rs_turbine_match_status", TABLE,
        "match_status IN ('not_checked', 'matched', 'partial', 'ambiguous', 'unmatched')",
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )


def downgrade():
    op.drop_constraint("ck_rs_turbine_match_status", TABLE, schema=SCHEMA_RATIONAL_STRUCTURE, type_="check")
    op.drop_index("ix_rs_turbine_version_machine", table_name=TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
    op.drop_constraint("fk_rs_turbine_machine", TABLE, schema=SCHEMA_RATIONAL_STRUCTURE, type_="foreignkey")
    op.drop_column(TABLE, "match_details", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.drop_column(TABLE, "match_status", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.drop_column(TABLE, "machine_id", schema=SCHEMA_RATIONAL_STRUCTURE)
