"""Технические характеристики становятся общими для турбин, гидротурбин и котлов.

Таблица gs_rs_turbine_technical_characteristics переименована в
gs_rs_equipment_technical_characteristics, столбец turbine_type – в equipment_type,
добавлены поля гидротурбин и котлов.
"""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_RATIONAL_STRUCTURE

revision = "rs26102602"
down_revision = "rs26102601"
branch_labels = None
depends_on = None

OLD_TABLE = "gs_rs_turbine_technical_characteristics"
TABLE = "gs_rs_equipment_technical_characteristics"
TURBINE_TYPES_SQL = "equipment_type IN ('steam', 'gas')"
EQUIPMENT_TYPES_SQL = "equipment_type IN ('steam', 'gas', 'hydro', 'boiler_energy', 'boiler_water')"
NEW_COLUMNS = (
    ("design_head", sa.Numeric(24, 8)),
    ("steam_capacity", sa.Numeric(24, 8)),
    ("heat_power", sa.Numeric(24, 8)),
    ("fuel_project", sa.Text()),
    ("fuel_main", sa.Text()),
    ("fuel_reserve", sa.Text()),
    ("efficiency_gross", sa.Numeric(24, 8)),
    ("water_consumption", sa.Numeric(24, 8)),
    ("operation_mode", sa.Text()),
)
RENAMED_INDEXES = (
    ("ix_rs_turbine_version_year_type", "ix_rs_equipment_version_year_type",
     ["database_version_id", "report_year", "equipment_type"]),
    ("ix_rs_turbine_version_machine", "ix_rs_equipment_version_machine",
     ["database_version_id", "machine_id"]),
    ("ix_rs_turbine_version_pgu_machine", "ix_rs_equipment_version_pgu_machine",
     ["database_version_id", "pgu_machine_id"]),
)


def _rename_indexes(*, reverse: bool):
    for old_name, new_name, columns in RENAMED_INDEXES:
        drop_name, create_name = (new_name, old_name) if reverse else (old_name, new_name)
        op.drop_index(drop_name, table_name=TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
        op.create_index(create_name, TABLE, columns, schema=SCHEMA_RATIONAL_STRUCTURE)


def upgrade():
    op.rename_table(OLD_TABLE, TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
    op.alter_column(
        TABLE, "turbine_type", new_column_name="equipment_type", type_=sa.String(20),
        existing_type=sa.String(10), schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.drop_constraint("ck_rs_turbine_type", TABLE, type_="check", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.create_check_constraint("ck_rs_equipment_type", TABLE, EQUIPMENT_TYPES_SQL, schema=SCHEMA_RATIONAL_STRUCTURE)
    op.drop_constraint("uq_rs_turbine_code_year_version", TABLE, type_="unique", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.create_unique_constraint(
        "uq_rs_equipment_code_year_version", TABLE,
        ["database_version_id", "equipment_type", "equipment_code", "report_year"],
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    _rename_indexes(reverse=False)
    for name, type_ in NEW_COLUMNS:
        op.add_column(TABLE, sa.Column(name, type_, nullable=True), schema=SCHEMA_RATIONAL_STRUCTURE)


def downgrade():
    for name, _ in NEW_COLUMNS:
        op.drop_column(TABLE, name, schema=SCHEMA_RATIONAL_STRUCTURE)
    # Старое ограничение допускает только паровые и газовые турбины.
    op.execute(sa.text(f"DELETE FROM {SCHEMA_RATIONAL_STRUCTURE}.{TABLE} WHERE equipment_type NOT IN ('steam', 'gas')"))
    _rename_indexes(reverse=True)
    op.drop_constraint("uq_rs_equipment_code_year_version", TABLE, type_="unique", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.create_unique_constraint(
        "uq_rs_turbine_code_year_version", TABLE,
        ["database_version_id", "equipment_type", "equipment_code", "report_year"],
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.drop_constraint("ck_rs_equipment_type", TABLE, type_="check", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.create_check_constraint("ck_rs_turbine_type", TABLE, TURBINE_TYPES_SQL, schema=SCHEMA_RATIONAL_STRUCTURE)
    op.alter_column(
        TABLE, "equipment_type", new_column_name="turbine_type", type_=sa.String(10),
        existing_type=sa.String(20), schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.rename_table(TABLE, OLD_TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
