"""Сохраненные расчетные книги наработки ЕГО и замыкающей цены."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_RATIONAL_STRUCTURE, SCHEMA_REFDATA
from migrations.column_utils import database_versions_physical_table_name

revision = "rs26102605"
down_revision = "rs26102604"
branch_labels = None
depends_on = None


def upgrade():
    version_table = database_versions_physical_table_name(op.get_bind(), SCHEMA_REFDATA)
    if version_table is None:
        raise RuntimeError("Не найдена таблица версий БД для расчетных книг.")
    op.create_table(
        "gs_rs_calculation_workbooks",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("database_version_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.{version_table}.id", ondelete="CASCADE"), nullable=False),
        sa.Column("kind", sa.String(30), nullable=False),
        sa.Column("source_filename", sa.Text(), nullable=False),
        sa.Column("source_sha256", sa.String(64), nullable=False),
        sa.Column("data", sa.JSON(), nullable=False),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("database_version_id", "kind", name="uq_rs_calculation_workbook_version_kind"),
        sa.CheckConstraint("kind IN ('equipment_runtime', 'marginal_price')", name="ck_rs_calculation_workbook_kind"),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.create_index(f"ix_{SCHEMA_RATIONAL_STRUCTURE}_gs_rs_calculation_workbooks_database_version_id",
                    "gs_rs_calculation_workbooks", ["database_version_id"], schema=SCHEMA_RATIONAL_STRUCTURE)


def downgrade():
    op.drop_table("gs_rs_calculation_workbooks", schema=SCHEMA_RATIONAL_STRUCTURE)
