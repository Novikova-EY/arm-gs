"""Технологии по энергозонам и матрицы МСК/МДП исходной книги."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_RATIONAL_STRUCTURE, SCHEMA_REFDATA
from migrations.column_utils import database_versions_physical_table_name

revision = "rs26102604"
down_revision = "rs26102603"
branch_labels = None
depends_on = None

NUMERIC_FIELDS = (
    "unit_power", "minimum_power", "capacity_factor_1", "capacity_factor_2",
    "capacity_factor_3", "capacity_factor_4", "standard_deviation", "capital_cost",
    "modernization_cost", "fuel_cost_winter", "fuel_cost_summer", "fixed_cost",
    "transmission_cost", "outage_probability_winter", "outage_probability_summer",
    "co2_per_fuel", "co2_per_energy", "quantity_min", "quantity_mod", "quantity_max",
)


def _common_columns(version_table):
    return [
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("database_version_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.{version_table}.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("source_row", sa.Integer(), nullable=False),
        sa.Column("source_filename", sa.Text(), nullable=False),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    ]


def upgrade():
    schema = SCHEMA_RATIONAL_STRUCTURE
    version_table = database_versions_physical_table_name(op.get_bind(), SCHEMA_REFDATA)
    if version_table is None:
        raise RuntimeError("Не найдена таблица версий БД для исходных данных по территориям.")
    op.create_table(
        "gs_rs_territory_technologies", *_common_columns(version_table),
        sa.Column("energy_zone_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.gs_sys_energy_zones.id", ondelete="CASCADE"), nullable=False),
        sa.Column("technology_number", sa.Integer(), nullable=False),
        *(sa.Column(field, sa.Float()) for field in NUMERIC_FIELDS),
        sa.UniqueConstraint("database_version_id", "energy_zone_id", "name", name="uq_rs_territory_technology"),
        schema=schema,
    )
    op.create_table(
        "gs_rs_territory_transfer_sections", *_common_columns(version_table),
        sa.Column("zone_membership", sa.JSON(), nullable=False),
        sa.Column("zone_paths", sa.JSON(), nullable=False),
        sa.Column("forward_limit", sa.Float(), nullable=False),
        sa.Column("reverse_limit", sa.Float(), nullable=False),
        sa.UniqueConstraint("database_version_id", "name", name="uq_rs_territory_transfer_section"),
        schema=schema,
    )
    for table in ("gs_rs_territory_technologies", "gs_rs_territory_transfer_sections"):
        op.create_index(f"ix_{schema}_{table}_database_version_id", table, ["database_version_id"], schema=schema)
    op.create_index(f"ix_{schema}_gs_rs_territory_technologies_energy_zone_id",
                    "gs_rs_territory_technologies", ["energy_zone_id"], schema=schema)


def downgrade():
    op.drop_table("gs_rs_territory_transfer_sections", schema=SCHEMA_RATIONAL_STRUCTURE)
    op.drop_table("gs_rs_territory_technologies", schema=SCHEMA_RATIONAL_STRUCTURE)
