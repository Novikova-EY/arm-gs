"""Технические характеристики паровых и газовых турбин."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_RATIONAL_STRUCTURE, SCHEMA_REFDATA
from migrations.column_utils import database_versions_physical_table_name

revision = "rs26102301"
down_revision = "eg26102201"
branch_labels = None
depends_on = None

TABLE = "gs_rs_turbine_technical_characteristics"
TEXT_FIELDS = (
    "equipment_kind", "subject_name", "station_name", "station_number",
    "equipment_subclass", "equipment_brand", "standard_service_life",
    "extension_decision", "assigned_service_life", "replaced_element",
    "remarking_reason", "decommissioning_reason", "recommissioning",
)
YEAR_FIELDS = (
    "commissioning_year", "expected_service_life_year", "last_overhaul_year",
    "element_replacement_year", "remarking_year", "decommissioning_year",
)
NUMBER_FIELDS = (
    "installed_electric_power", "nominal_active_power", "technical_min_power",
    "technical_max_power", "total_heat_power", "district_heat_power",
    "electricity_generation", "heat_output", "operating_hours_total",
    "operating_hours_year", "standard_start_count", "start_count_total",
    "start_count_year", "standard_overhaul_hours", "hours_since_overhaul", "extension_count",
)


def upgrade():
    conn = op.get_bind()
    version_table = database_versions_physical_table_name(conn, SCHEMA_REFDATA)
    if version_table is None:
        raise RuntimeError("Не найдена таблица версий БД для технических характеристик.")
    op.execute(sa.schema.CreateSchema(SCHEMA_RATIONAL_STRUCTURE, if_not_exists=True))
    op.create_table(
        TABLE,
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("database_version_id", sa.Integer(), nullable=False),
        sa.Column("turbine_type", sa.String(10), nullable=False),
        sa.Column("equipment_code", sa.String(100), nullable=False),
        sa.Column("report_year", sa.Integer(), nullable=False),
        *(sa.Column(name, sa.Text()) for name in TEXT_FIELDS),
        *(sa.Column(name, sa.Integer()) for name in YEAR_FIELDS),
        *(sa.Column(name, sa.Numeric(24, 8)) for name in NUMBER_FIELDS),
        sa.Column("extra_values", sa.JSON(), nullable=False),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["database_version_id"], [f"{SCHEMA_REFDATA}.{version_table}.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("database_version_id", "turbine_type", "equipment_code", "report_year", name="uq_rs_turbine_code_year_version"),
        sa.CheckConstraint("turbine_type IN ('steam', 'gas')", name="ck_rs_turbine_type"),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    op.create_index("ix_rs_turbine_version_year_type", TABLE, ["database_version_id", "report_year", "turbine_type"], schema=SCHEMA_RATIONAL_STRUCTURE)


def downgrade():
    op.drop_table(TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
