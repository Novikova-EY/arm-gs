"""Связь технических характеристик с компонентами ПГУ."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_GENERATION, SCHEMA_RATIONAL_STRUCTURE

revision = "rs26102303"
down_revision = "rs26102302"
branch_labels = None
depends_on = None

TABLE = "gs_rs_turbine_technical_characteristics"


def upgrade():
    op.add_column(TABLE, sa.Column("pgu_machine_id", sa.Integer(), nullable=True), schema=SCHEMA_RATIONAL_STRUCTURE)
    op.create_foreign_key(
        "fk_rs_turbine_pgu_machine", TABLE, "gs_gen_pgu_machines", ["pgu_machine_id"], ["id"],
        source_schema=SCHEMA_RATIONAL_STRUCTURE, referent_schema=SCHEMA_GENERATION,
        ondelete="SET NULL",
    )
    op.create_index(
        "ix_rs_turbine_version_pgu_machine", TABLE, ["database_version_id", "pgu_machine_id"],
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )


def downgrade():
    op.drop_index("ix_rs_turbine_version_pgu_machine", table_name=TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
    op.drop_constraint("fk_rs_turbine_pgu_machine", TABLE, schema=SCHEMA_RATIONAL_STRUCTURE, type_="foreignkey")
    op.drop_column(TABLE, "pgu_machine_id", schema=SCHEMA_RATIONAL_STRUCTURE)
