"""Stations used exclusively on the electricity generation page."""
from alembic import op
import sqlalchemy as sa
from config import SCHEMA_GENERATION

revision = "gs26102701"
down_revision = "rs26102701"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("gs_gen_stations", sa.Column(
        "is_generation_only", sa.Boolean(), nullable=False, server_default=sa.false()
    ), schema=SCHEMA_GENERATION)


def downgrade():
    op.drop_column("gs_gen_stations", "is_generation_only", schema=SCHEMA_GENERATION)
