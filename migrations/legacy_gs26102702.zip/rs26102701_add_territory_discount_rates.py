"""Общая ставка дисконтирования ЕЭС России по версиям БД."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_RATIONAL_STRUCTURE, SCHEMA_REFDATA
from migrations.column_utils import database_versions_physical_table_name

revision = "rs26102701"
down_revision = "eb26102701"
branch_labels = None
depends_on = None


def upgrade():
    version_table = database_versions_physical_table_name(op.get_bind(), SCHEMA_REFDATA)
    if version_table is None:
        raise RuntimeError("Не найдена таблица версий БД для ставки дисконтирования.")
    op.create_table(
        "gs_rs_territory_discount_rates",
        sa.Column("database_version_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.{version_table}.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("year_values", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )


def downgrade():
    op.drop_table("gs_rs_territory_discount_rates", schema=SCHEMA_RATIONAL_STRUCTURE)
