"""Отдельные параметры групп для страниц АЭС, ГЭС и СЭС–ВЭС."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_ENERGY_BALANCE, SCHEMA_GENERATION

revision = "eb26102701"
down_revision = "ee26102701"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "gs_bem_ee_balance_station_group_values",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("id_station_group", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_GENERATION}.gs_gen_station_groups.id", ondelete="CASCADE"), nullable=False),
        sa.Column("page_key", sa.String(16), nullable=False),
        sa.Column("year_number", sa.Integer(), nullable=False),
        sa.Column("energy", sa.Numeric(25, 16)),
        sa.Column("own_needs", sa.Numeric(25, 16)),
        sa.Column("own_needs_percent", sa.Numeric(25, 16)),
        sa.Column("database_version_id", sa.Integer()),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("page_key IN ('aes', 'ges', 'ses-ves')", name="ck_ee_balance_group_page"),
        schema=SCHEMA_ENERGY_BALANCE,
    )
    op.create_index("uq_ee_balance_group_page_year_version", "gs_bem_ee_balance_station_group_values",
                    ["id_station_group", "page_key", "year_number", sa.text("COALESCE(database_version_id, -1)")],
                    unique=True, schema=SCHEMA_ENERGY_BALANCE)
    op.create_index("ix_ee_balance_group_version",
                    "gs_bem_ee_balance_station_group_values", ["database_version_id"], schema=SCHEMA_ENERGY_BALANCE)


def downgrade():
    op.drop_table("gs_bem_ee_balance_station_group_values", schema=SCHEMA_ENERGY_BALANCE)
