"""Коды Техинспекции без копирования годовых характеристик."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_GENERATION, SCHEMA_RATIONAL_STRUCTURE, SCHEMA_REFDATA
from migrations.column_utils import database_versions_physical_table_name

revision = "rs26102601"
down_revision = "rs26102303"
branch_labels = None
depends_on = None

TABLE = "gs_rs_technical_inspection_codes"


def upgrade():
    conn = op.get_bind()
    version_table = database_versions_physical_table_name(conn, SCHEMA_REFDATA)
    if version_table is None:
        raise RuntimeError("Не найдена таблица версий БД для кодов Техинспекции.")
    op.create_table(
        TABLE,
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("database_version_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.{version_table}.id", ondelete="CASCADE"), nullable=False),
        sa.Column("equipment_code", sa.String(100), nullable=False),
        sa.Column("machine_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_GENERATION}.gs_gen_machines.id", ondelete="CASCADE"), nullable=False),
        sa.Column("pgu_machine_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_GENERATION}.gs_gen_pgu_machines.id", ondelete="CASCADE")),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        sa.UniqueConstraint("database_version_id", "equipment_code", name="uq_rs_inspection_code_version"),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )
    for column in ("machine_id", "pgu_machine_id"):
        op.create_index(f"ix_rs_inspection_codes_{column}", TABLE, [column], schema=SCHEMA_RATIONAL_STRUCTURE)


def downgrade():
    op.drop_table(TABLE, schema=SCHEMA_RATIONAL_STRUCTURE)
