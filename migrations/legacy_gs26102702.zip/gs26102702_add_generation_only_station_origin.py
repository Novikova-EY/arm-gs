"""Keep the creation origin when a generation-only station becomes ordinary."""
from alembic import op
import sqlalchemy as sa
from config import SCHEMA_GENERATION

revision = "gs26102702"
down_revision = "gs26102701"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("gs_gen_stations", sa.Column(
        "created_as_generation_only", sa.Boolean(), nullable=False, server_default=sa.false()
    ), schema=SCHEMA_GENERATION)
    stations = sa.table("gs_gen_stations",
                        sa.column("is_generation_only", sa.Boolean()),
                        sa.column("created_as_generation_only", sa.Boolean()),
                        schema=SCHEMA_GENERATION)
    op.execute(stations.update().where(stations.c.is_generation_only.is_(True)).values(
        created_as_generation_only=True
    ))


def downgrade():
    op.drop_column("gs_gen_stations", "created_as_generation_only", schema=SCHEMA_GENERATION)
