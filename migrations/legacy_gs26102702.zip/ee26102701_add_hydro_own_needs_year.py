"""Годовые коэффициенты собственных нужд ГЭС.

Revision ID: ee26102701
Revises: rs26102605
"""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_ENERGY_BALANCE

revision = "ee26102701"
down_revision = "rs26102605"
branch_labels = None
depends_on = None

TABLE = "gs_bem_ee_balance_station_own_needs_coefficients"
OLD_INDEX = "uq_ee_bal_own_needs_station_type_ver"
NEW_INDEX = "uq_ee_bal_own_needs_station_type_year_ver"


def upgrade():
    inspector = sa.inspect(op.get_bind())
    columns = {column["name"]: column for column in inspector.get_columns(TABLE, schema=SCHEMA_ENERGY_BALANCE)}
    indexes = {index["name"] for index in inspector.get_indexes(TABLE, schema=SCHEMA_ENERGY_BALANCE)}
    # Support targeted application when unrelated pending revisions block the local upgrade chain.
    if "year_number" not in columns:
        op.add_column(TABLE, sa.Column("year_number", sa.Integer(), nullable=True), schema=SCHEMA_ENERGY_BALANCE)
    # NULL in a yearly row explicitly clears the value inherited from the old station-wide coefficient.
    if not columns["coefficient"]["nullable"]:
        op.alter_column(TABLE, "coefficient", nullable=True, schema=SCHEMA_ENERGY_BALANCE)
    if OLD_INDEX in indexes:
        op.drop_index(OLD_INDEX, table_name=TABLE, schema=SCHEMA_ENERGY_BALANCE)
    if NEW_INDEX not in indexes:
        op.create_index(
            NEW_INDEX, TABLE,
            ["id_station", "station_type_key", sa.text("COALESCE(year_number, -1)"),
             sa.text("COALESCE(database_version_id, -1)")],
            unique=True, schema=SCHEMA_ENERGY_BALANCE,
        )


def downgrade():
    bind = op.get_bind()
    table = sa.table(TABLE, sa.column("year_number"), schema=SCHEMA_ENERGY_BALANCE)
    if bind.execute(sa.select(sa.func.count()).select_from(table).where(table.c.year_number.is_not(None))).scalar():
        raise RuntimeError("Нельзя отменить миграцию: сохранены годовые коэффициенты СН")
    op.drop_index(NEW_INDEX, table_name=TABLE, schema=SCHEMA_ENERGY_BALANCE)
    op.create_index(
        OLD_INDEX, TABLE,
        ["id_station", "station_type_key", sa.text("COALESCE(database_version_id, -1)")],
        unique=True, schema=SCHEMA_ENERGY_BALANCE,
    )
    op.alter_column(TABLE, "coefficient", nullable=False, schema=SCHEMA_ENERGY_BALANCE)
    op.drop_column(TABLE, "year_number", schema=SCHEMA_ENERGY_BALANCE)
