"""Модуль события в общем журнале, включая существующие записи."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_LOGS

revision = "lg26102601"
down_revision = "rs26102602"
branch_labels = None
depends_on = None

# Снимок правил на дату миграции: последующие переименования модулей не меняют историю.
ENDPOINT_MODULES = {'start': 'Главная',
 'auth': 'Авторизация',
 'users_bp': 'Пользователи',
 'refdata_bp': 'Справочники',
 'generation_bp': 'Генерация',
 'station_bp': 'Генерация',
 'station_changes_bp': 'Генерация',
 'prospective_places_bp': 'Генерация',
 'rational_structure_bp': 'Рациональная структура',
 'rational_structure_module_bp': 'Рациональная структура',
 'fuel_bp': 'Топливо',
 'power_demand_bp': 'Нагрузки',
 'energy_consumption_bp': 'Спрос',
 'long_term_consumption_bp': 'Долгосрочный прогноз потребления',
 'electrical_intensity_root_bp': 'Долгосрочный прогноз потребления',
 'energy_balance_bp': 'Балансы электрической энергии и мощности',
 'ecology_bp': 'Экология',
 'economics_bp': 'Экономика',
 'territories_bp': 'Характеристики территорий',
 'logs': 'Журнал',
 'history_bp': 'История',
 'perimeter_variant_bp': 'Варианты сценариев',
 'year_management': 'Справочники',
 'exchange_api_bp': 'Обмен данными',
 'database_versions_api_bp': 'Справочники'}
PATH_MODULES = {'Рациональная структура': ['rational_structure'],
 'Генерация': ['generation'],
 'Топливо': ['fuel'],
 'Нагрузки': ['power_demand'],
 'Спрос': ['energy_consumption'],
 'Долгосрочный прогноз потребления': ['electrical_intensity', 'long_term_consumption'],
 'Балансы электрической энергии и мощности': ['energy_balance'],
 'Экология': ['ecology'],
 'Экономика': ['economics'],
 'Характеристики территорий': ['territories'],
 'Справочники': ['refdata'],
 'Авторизация': ['auth'],
 'Журнал': ['log']}
ENTITY_MODULES = {'Рациональная структура': ('rational_structure', 'rational_structure_code'),
 'Генерация': ('station',
               'machine',
               'pgu_machine',
               'document',
               'import_fuel',
               'gaes_tep_source',
               'ges_tep_source',
               'prospective_place_aes',
               'prospective_place_gaes',
               'prospective_place_ges'),
 'Топливо': ('fuel',
             'distribution_parameter',
             'cities',
             'gen_company_branch',
             'import_fuel_db_equipment_groups',
             'soft_import_composite_flags',
             'territories_energy',
             'import_equipment_group_fuel_params',
             'import_equipment_groups'),
 'Экология': ('ecology',),
 'Экономика': ('long_term_accum_fixed_capital',
               'long_term_accum_monetary_income',
               'long_term_population',
               'long_term_product_output',
               'long_term_ved_consumption'),
 'Долгосрочный прогноз потребления': ('long_term_electrical_intensity',),
 'Балансы электрической энергии и мощности': ('energy_balance',
                                              'ee_generation_import',
                                              'ee_transfers_import'),
 'Характеристики территорий': ('energy_unit_power_transfer',),
 'Нагрузки': ('pd_summ_oes_max',
              'power_demand_summary_ez',
              'power_demand_summary_fo',
              'power_demand_summary_oes'),
 'Спрос': ('energy_consumption_summary_ez',
           'energy_consumption_summary_fo',
           'energy_consumption_summary_oes'),
 'Пользователи': ('user',),
 'Справочники': ('business_unit',
                 'condition_type',
                 'database_version',
                 'department',
                 'economic_activity_type',
                 'economic_region',
                 'electricity_production_cost_type',
                 'energy_area',
                 'energy_system_type',
                 'energy_unit',
                 'energy_zone',
                 'energy_zone_external_mapping',
                 'equipment_group',
                 'federal_district',
                 'foreign_border_country',
                 'fuel_type',
                 'gen_company',
                 'machine_type',
                 'pgu_tes_machine_type',
                 'refdata_history',
                 'regional_district',
                 'regional_energy_system',
                 'regional_energy_system_external_mapping',
                 'station_type',
                 'synchronous_area',
                 'technology',
                 'technology_availability',
                 'technology_type',
                 'tes_machine_type',
                 'tes_type',
                 'union_energy_system',
                 'year')}

def upgrade():
    # Локальные установки могут применять эту миграцию отдельно от старой цепочки.
    columns = sa.inspect(op.get_bind()).get_columns("logs", schema=SCHEMA_LOGS)
    if any(column["name"] == "module" for column in columns):
        return
    op.add_column("logs", sa.Column("module", sa.String(100), nullable=True), schema=SCHEMA_LOGS)
    logs = sa.table("logs", sa.column("module", sa.String(100)),
                    sa.column("entity_type", sa.String(50)), sa.column("details", sa.Text),
                    sa.column("action", sa.String(500)), schema=SCHEMA_LOGS)
    rules = []
    for endpoint, module in ENDPOINT_MODULES.items():
        rules.append((logs.c.details.contains(f"endpoint={endpoint}.", autoescape=True), module))
    for module, paths in PATH_MODULES.items():
        for path in paths:
            rules.append((logs.c.details.contains(f"/{path}/", autoescape=True), module))
    # В старых журналах открытий встречаются url без endpoint, а в фоновых задачах – только entity_type.
    for module, entities in ENTITY_MODULES.items():
        rules.append((logs.c.entity_type.in_(entities), module))
    for pattern in (
        "Обновление p_rasp%", "Пересчет огранич%мощности%", "Обновление располагаемой мощности%",
        "Создание мощности%", "Обновление мощности%", "Создание типа ТЭС%", "Обновление типа ТЭС%",
        "Создание топлива%", "Удаление топлива%", "Создание вида топлива%", "Обновление агрегата%",
        "Создание агрегата%", "Создание станции%", "Открыта страница электростанций%",
    ):
        rules.append((logs.c.action.ilike(pattern), "Генерация"))
    for term in ("вход", "авторизац", "регистрац", "вышел из системы"):
        rules.append((logs.c.action.ilike(f"%{term}%"), "Авторизация"))
    op.execute(logs.update().values(module=sa.case(*rules, else_="Система")))
    op.alter_column("logs", "module", existing_type=sa.String(100), nullable=False,
                    server_default="Система", schema=SCHEMA_LOGS)
    op.create_index(f"ix_{SCHEMA_LOGS}_logs_module", "logs", ["module"], schema=SCHEMA_LOGS)


def downgrade():
    op.drop_index(f"ix_{SCHEMA_LOGS}_logs_module", table_name="logs", schema=SCHEMA_LOGS)
    op.drop_column("logs", "module", schema=SCHEMA_LOGS)
