"""Исходные данные по территориям в разрезе энергозон и версий БД."""
from alembic import op
import sqlalchemy as sa

from config import SCHEMA_RATIONAL_STRUCTURE, SCHEMA_REFDATA
from migrations.column_utils import database_versions_physical_table_name

revision = "rs26102603"
down_revision = "lg26102601"
branch_labels = None
depends_on = None


def upgrade():
    version_table = database_versions_physical_table_name(op.get_bind(), SCHEMA_REFDATA)
    if version_table is None:
        raise RuntimeError("Не найдена таблица версий БД для исходных данных по территориям.")
    op.create_table(
        "gs_rs_territory_inputs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("database_version_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.{version_table}.id", ondelete="CASCADE"), nullable=False),
        sa.Column("energy_zone_id", sa.Integer(), sa.ForeignKey(
            f"{SCHEMA_REFDATA}.gs_sys_energy_zones.id", ondelete="CASCADE"), nullable=False),
        sa.Column("years", sa.JSON(), nullable=False),
        sa.Column("rows", sa.JSON(), nullable=False),
        sa.Column("source_filename", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("created_by", sa.String(255)),
        sa.Column("modified_by", sa.String(255)),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("database_version_id", "energy_zone_id", name="uq_rs_territory_input_version_zone"),
        schema=SCHEMA_RATIONAL_STRUCTURE,
    )


def downgrade():
    op.drop_table("gs_rs_territory_inputs", schema=SCHEMA_RATIONAL_STRUCTURE)
